#ifndef PERIMETER_H
#define	PERIMETER_H

double calculate_perimeter(double s, int n);

#endif	/* PERIMETER_H */

