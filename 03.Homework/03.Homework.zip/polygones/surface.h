#ifndef SURFACE_H
#define	SURFACE_H

double calculate_area(double s, int n);

#endif	/* SURFACE_H */

