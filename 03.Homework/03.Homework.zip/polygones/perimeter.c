#include "perimeter.h"

double calculate_perimeter(double s, int n) {
    double perimeter = s * n;
    return perimeter;
}